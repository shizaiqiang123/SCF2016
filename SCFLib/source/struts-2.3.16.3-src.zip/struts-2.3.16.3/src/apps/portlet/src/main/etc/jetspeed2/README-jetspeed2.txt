Copy the struts-portlet.psml file to the JETSPEED2_INSTALL_DIR/webapps/jetspeed/WEB-INF/pages directory.
